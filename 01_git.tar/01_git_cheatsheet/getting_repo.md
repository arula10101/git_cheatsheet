# Getting a Git Repo

-   Creating a repo from a directory:
    
        git init
-   Cloning a repo:
    
        git clone repo_url
